//=============================================================--
// Nom de l'�tudiant   : David FISCHER TE3
// Nom du projet       : Cam�ra CMOS 2006
// Nom du C++          : Cam�raCMOS.cpp
// Nom de la FPGA      : Cyclone - EP1C12F256C7
// Nom de la puce USB2 : Cypress - FX2
// Nom du compilateur  : Qt / qmake -project / qmake / make
//=============================================================--

#include "CypressEzUSBDevice.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <sys/time.h>
#include <windows.h>
#include <winbase.h>

#include <iostream.h>

#define NODEBUG 1

using namespace std;

//=============================================================--

CypressEzUSBDevice DeviceFX2;

/*	virtual bool open(const QString &firmwareFilename);
	virtual bool close(void);
	virtual bool setInterface(unsigned number, unsigned alternateSetting);
	virtual unsigned bulkRead(unsigned pipeNum, char *buffer, size_t size);
	virtual unsigned bulkWrite(unsigned pipeNum, const char *buffer, size_t size);
	virtual bool GetHandle(void);
	virtual void setOverlapped(bool Value);*/

void ToHex (unsigned char Nombre, char* Texte)
{
    _itoa (Nombre, Texte, 16);
    
    if (Nombre < 16)
    {
        Texte[1] = Texte[0];
        Texte[0] = '0';
    }
    
    Texte[2] = ' ';
    Texte[3] = 0;
}

int ToInt_Hex (unsigned char Hex)
{
    if      (Hex >= '0' && Hex <= '9') return Hex-'0';
    else if (Hex >= 'a' && Hex <= 'f') return Hex-'a'+10;
    
    return 0;
}

unsigned char ToInt (unsigned char HexFort, unsigned char HexFaible)
{
    return ToInt_Hex(HexFort)*16+ToInt_Hex(HexFaible);
}

void CaptureBuffer ()
{
    const int Total = 512*512;

    unsigned char Buffer[Total];
    int Numero = 0;
    
    while (Numero < Total)
    {
        int Nombre;

        Nombre = DeviceFX2.bulkRead (0, (char*)&Buffer[Numero], 512);
        
        if (Nombre > 0) Numero += Nombre;
    }
    
    FILE *Fichier = fopen ("bufferFX2.txt","w");
    
    if (Fichier == NULL)
    {
        fprintf (stderr, "Erreur dans l'ouverture du fichier");
        exit (-1);
    }

    for (int No = 0; No < Total; No+=2)
    {
        char Texte[4];
        
        ToHex (Buffer[No+1], Texte); fprintf (Fichier, Texte);
        ToHex (Buffer[No+0], Texte); fprintf (Fichier, Texte);
        
        if ((No > 0) && ((No+2) % 16 == 0))
             fprintf (Fichier, "\n");
        else fprintf (Fichier, "- ");
    }

    fclose (Fichier);
}

void DecoupeCapture ()
{
    const int Total = 512*512;

    unsigned char Buffer[Total*4];
    int Numero = 0;
    
    FILE *Fichier = fopen ("bufferFX2.txt","r");
    FILE *Fichier2 = fopen ("traiteFX2.txt","w");
    
    if (Fichier == NULL)
    {
        fprintf (stderr, "Erreur dans l'ouverture du fichier");
        exit (-1);
    }
    
    Numero = fread (Buffer, Total, 1, Fichier);
    
    //fprintf (Fichier2, "%s", Buffer);

    for (int No = 0; No < Total*4;)
    {
        char Texte[4];
        
        // Fort  Faib
        // H L e H L e - e
        // 0 1 2 3 4 5 6 7
        
        unsigned char Fort   = ToInt (Buffer[No+0],Buffer[No+1]);
        unsigned char Faible = ToInt (Buffer[No+3],Buffer[No+4]);
        
        if ((Fort & 0x80) == 0x80)
        {
            fprintf (Fichier2, "\nImage ");
        }
        else if ((Fort & 0xC0) == 0x40)
        {
             fprintf (Fichier2, "L ");
        }
        else if ((Fort & 0xE0) == 0x20)
        {
             fprintf (Fichier2, "Crc ");
        }
        else if ((Fort & 0xF0) == 0x10)
        {
             if ((Fort & 0xFF) == 0x10) fprintf (Fichier2, "r");
             else if ((Fort & 0xFF) == 0x11) fprintf (Fichier2, "v");
             else if ((Fort & 0xFF) == 0x12) fprintf (Fichier2, "b ");
             else if ((Fort & 0xFF) == 0x14) fprintf (Fichier2, "h");
             else if ((Fort & 0xFF) == 0x15) fprintf (Fichier2, "s");
             else if ((Fort & 0xFF) == 0x16) fprintf (Fichier2, "l ");
             else fprintf (Fichier2, "X ");
             
        }
				
        //ToHex (Fort, Texte); fprintf (Fichier2, Texte);

        if (Buffer[No+6] != '-') No += 7;
        else                     No += 8;
    }

    fclose (Fichier);
    fclose (Fichier2);
}

int main (int argc, char **argv)
{

    //if (DeviceFX2.open ("./bulksrc.bix"))
    //{ 

    Sleep(500);

    //CaptureBuffer ();
    DecoupeCapture ();

    //}
	 	
	return 0;
};
