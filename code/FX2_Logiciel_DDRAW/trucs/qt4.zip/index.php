<?
		$rubrique = 3;
		$meta_description = "Installation de la biblioth�que graphique Qt4 sous Windows avec Dev-cpp";
		$meta_keywords = "Qt, dev-cpp, c++, gui";
		$titre_page = "Installer Qt4 sous Windows";
		$urlCss = "./article.css";
		$xhtml=true;
		
			$Auteur="Nicolas Joseph";
			$Licence="2";
			$Annee="2006";
		
		$dateBrute['date'] = '18 Juillet 2005';
		$dateBrute['miseajour'] = '';
		
				$topicType = 'Whitepaper';
			include("$DOCUMENT_ROOT/template/entete.php");?>
<div style="text-align:center;">
	<table class="cadrearticle" width="90%" cellpadding="10" cellspacing="0">
		<tr>
			<td align="center" style="text-align:left">
		<br/><h1>Installer Qt4 sous Windows</h1><p class="dateArticle">Date de publication : 18 Juillet 2005</p><p style="text-align: center;">
		Par
		<a class="auteur" href="http://www.developpez.net/forums/member.php?u=41072">Nicolas Joseph</a> <a class="homepage" href="http://nicolasj.developpez.com"> (home)</a> <a class="homepage" href="http://blog.developpez.com/?blog=58">(Blog)</a><br/>&nbsp;</p><div class="synopsis">
	  Cet article a pour but d'expliquer l'installation de Qt4 sous Windows afin de developper une application graphique avec Dev-cpp.
	</div>
		<br /><a class="summaryIndent0" href="#LI">I. Introduction</a>
			
			
		
		<br /><a class="summaryIndent0" href="#LII">II. T�l�chargement</a>
			
			
			
		
		<br /><a class="summaryIndent0" href="#LIII">III. Installer Dev-cpp</a>
			
			
		
		<br /><a class="summaryIndent0" href="#LIV">IV. Installer Qt</a>
			
			
		
		<br /><a class="summaryIndent0" href="#LV">V. Cr�ation du template</a>
			
			

			

			<br /><a class="summaryIndent1" href="#LV-A">V-A. [Template]</a>
				
				

				
				
				
			
			<br /><a class="summaryIndent1" href="#LV-B">V-B. [Unit]</a>
				
				

				

				
				
			
			<br /><a class="summaryIndent1" href="#LV-C">V-C. [Project]</a>
				
				

				
				
				

				

							
			
		
		<br /><a class="summaryIndent0" href="#LVI">VI. Conclusion</a>
			
			
		
		<br /><a class="summaryIndent0" href="#LVII">VII. Remerciements</a>
			
			
		
	<br/><br/>
		<br /><h1 class="TitreSection0" id="LI">I. Introduction</h1>
			
			<div class="paragraph">
				Depuis la version 4, la biblioth�que <b>Qt</b> (d�velopp�e par <a href="http://www.trolltech.com" class="lienArticle">Trolltech</a>) est disponible gratuitement sous <b>Windows</b> (uniquement pour le d�veloppement d'applications � but non commercial). Autre restriction impos�e par <b>Trolltech</b>, la compilation ne peut se faire qu'� l'aide de <a href="http://www.mingw.org" class="lienArticle">Mingw</a> c'est pourquoi <a href="http://www.bloodshed.net" class="lienArticle">Dev-cpp</a> est un IDE de choix pour le d�veloppement d'applications bas�es sur cette biblioth�que.
			</div><br/>
		
		<br /><h1 class="TitreSection0" id="LII">II. T�l�chargement</h1>
			
			<div class="paragraph">
				Avant de nous lancer dans l'installation de <b>Qt</b>, il faut vous assurer d'avoir tous les packages n�cessaires � cette installation :
			</div><br/>
			<ul style="list-style-type: disc;">
				<li><a href="http://www.bloodshed.net" class="lienArticle">Dev-cpp</a> de pr�f�rence avec le package <b>Mingw</b></li>
				<li><a href="http://www.trolltech.com/download/opensource.html" class="lienArticle">Qt</a> version 4 minimum</li>
			</ul>
		
		<br /><h1 class="TitreSection0" id="LIII">III. Installer Dev-cpp</h1>
			
			<div class="paragraph">
				Une fois ces packages en votre possession, commencez par installer <b>Dev-cpp</b>. Je suppose par la suite qu'il est install� dans le r�pertoire <i>C:\Dev-Cpp</i>.
			</div><br/>
		
		<br /><h1 class="TitreSection0" id="LIV">IV. Installer Qt</h1>
			
			<div class="paragraph">
				 Une fois l'intallation de <b>Dev-cpp</b> correctement effectu�e, vous pouvez installer <b>Qt</b>. La premi�re chose que vous demande l'installeur de <b>Qt</b> est le r�pertoire o� se trouve <b>Mingw</b>, il faut pr�ciser le r�pertoire racine de <b>Dev-cpp</b> (<i>C:\Dev-Cpp</i> dans notre exemple). Ensuite, il ne vous reste plus qu'� pr�ciser le r�pertoire d'installation de <b>Qt</b> (<i>C:\Qt</i> sera utilis� par la suite).
			</div><br/>
		
		<br /><h1 class="TitreSection0" id="LV">V. Cr�ation du template</h1>
			
			<div class="paragraph">
				Le but de cette �tape est d'obtenir une entr�e pour <b>Qt</b> dans la bo�te de dialogue "Nouveau projet" de <b>Dev-cpp</b>. Pour la gestion des projets, <b>Dev-cpp</b> utilise un syst�me de templates qui est en fait un fichier texte regroupant les options sp�cifiques � chaque type de projet. Voici un exemple de fichier template utilis� pour les projets "Windows Application" :
			</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="ini_code">[Template]
ver=1
Name=Windows Application
IconIndex=0
Description=A standard Windows application
Catagory=Basic

[Unit0]
CName=main.c
CppName=main.cpp
C=winapp_c.txt
Cpp=winapp_c.txt

[Project]
UnitCount=1
Type=0
Name=Windows App</span></pre></td></tr></table></div>
			<div class="paragraph">
				Nous allons donc nous inspirer de cet exemple pour cr�er un template <b>Qt</b>. Certains attributs ne seront pas pr�sents et d'autres vont �tre ajout�s.
			</div><br/>

			<br /><h2 class="TitreSection1" id="LV-A">V-A. [Template]</h2>
				
				<div class="paragraph">
					La partie <i>Template</i> permet de personnaliser ce qui va �tre affich� dans la bo�te de dialogue de cr�ation d'un nouveau projet. Pour notre type de projet, voici un exemple de ce qui peut �tre fait :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="ini_code">[Template]
ver=1
Name=Qt
Icon=Qt.ico
Description=Create a GUI using the Qt library.
Catagory=GUI</span></pre></td></tr></table></div>
				<div class="paragraph">
					Plut�t qu'un long discours, voici le r�sultat :
				</div><br/>
				<div class="image"><img src="./images/fig1.png" alt=""/></div>
				<div class="paragraph">
					Donc, <i>Name</i> est le texte affich� sous l'ic�ne dont le chemin de l'image est sp�cifi� par l'attribut <i>Icon</i> (j'ai trouv� cette ic�ne dans le r�pertoire <i>C:\Qt\examples\tools\qtdemo</i>). Le champ <i>Description</i> est affich� dans la partie... Description et enfin <i>Category</i> permet de choisir l'onglet sous lequel va se trouver notre projet.
				</div><br/>
			
			<br /><h2 class="TitreSection1" id="LV-B">V-B. [Unit]</h2>
				
				<div class="paragraph">
					Cette partie permet d'associer un fichier au projet, <i>Unit</i> doit �tre suivi d'un chiffre qui sera incr�ment� pour chaque fichier. Dans notre cas, nous aurons qu'un seul fichier et par cons�quent qu'une seule section nomm�e Unit0 :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="ini_code">[Unit0]
CppName=main.cpp
Cpp=qt_cpp.txt</span></pre></td></tr></table></div>
				<div class="paragraph">
					Deux attributs sont � renseigner : le premier est le nom par d�faut sous lequel sera enregist� le fichier, quant au second, c'est le nom du fichier qui servira de mod�le, dont voici un exemple :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="titre_code">qt_cpp.txt</td></tr><tr><td class="code"><pre><span class="cpp_code"><span class="cpp_define">#include &lt;QApplication&gt;</span>
<span class="cpp_define">#include &lt;QPushButton&gt;</span>

<span class="cpp_keyword"><span class="cpp_type">int</span></span> main(<span class="cpp_keyword"><span class="cpp_type">int</span></span> argc, <span class="cpp_keyword"><span class="cpp_type">char</span></span> *argv[])
{
    QApplication app(argc, argv);

    QPushButton hello(<span class="cpp_ch">"Hello world!"</span>);
    hello.resize(100, 30);

    hello.show();
    <span class="cpp_keyword">return</span> app.exec();
}</span></pre></td></tr></table></div>
				<div class="paragraph">
					Une fois la cr�ation du projet valid�, voici le r�sultat :
				</div><br/>
				<div class="image"><img src="./images/fig2.png" alt=""/></div>
			
			<br /><h2 class="TitreSection1" id="LV-C">V-C. [Project]</h2>
				
				<div class="paragraph">
					Pour terminer, il nous reste le plus important : les options concernant l'ensemble du projet. Voici la deni�re partie du fichier template :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="ini_code">[Project]
UnitCount=1
Type=1
IsCpp=1
CppCompiler=...
Linker=...
ProjectIcon=Qt.ico</span></pre></td></tr></table></div>
				<div class="paragraph">
					Voici le r�le de chaque attribut :
				</div><br/>
				<ul style="list-style-type: disc;">
					<li>UnitCount : c'est le nombre de parties [Unit], dans notre cas une seule</li>
					<li>Type : permet de pr�ciser le type de projet (1 pour Win32 Console) :</li>
					<div class="image" style="text-align:center;"><img src="./images/fig3.png" alt=""/></div>
					<li>IsCpp : comme <b>Qt</b> est une biblioth�que utilisable qu'en C++, cela �vite de cr�er un projet C :</li>
					<div class="image" style="text-align:center;"><img src="./images/fig4.png" alt=""/></div>
					<li>CppCompiler : ce sont les options du compilateur C++, je vais expliquer comment les r�cup�rer</li>
					<li>Linker : m�me remarque que ci-dessus pour les options du linker</li>
					<li>ProjectIcon : c'est l'ic�ne associ�e au projet</li>
				</ul>
				<div class="paragraph">
					Pour r�cup�rer les options du compilateur et du linker, il faut commencer par ouvrir une fen�tre de commande Dos puis placez vous dans le dossier <i>C:\Qt\examples\tutorial\t1</i> :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="other_code">C:\&gt;cd C:\Qt\examples\tutorial\t1</span></pre></td></tr></table></div>
				<div class="paragraph">
					Puis tapez les commandes suivantes :
				</div>
<div style="text-align:center;"><table style="width:90%;margin:10px auto;border-collapse: collapse;"><tr><td class="code"><pre><span class="other_code">C:\Qt\examples\tutorial\t1&gt;qmake -project
C:\Qt\examples\tutorial\t1&gt;qmake</span></pre></td></tr></table></div>
				<div class="paragraph">
					Maintenant dans le r�pertoire <i>C:\Qt\examples\tutorial\t1</i>, vous obtenez plusieurs nouveaux fichiers dont un nomm� <i>Makefile.Release</i>, ouvrez le avec votre �diteur de texte pr�f�r�. Ensuite, il suffit de copier les valeurs des attributs DEFINE, CXXFLAGS et INCPATH les uns � la suite des autres pour former les options du compilateur (CppCompiler) et ceux de la ligne LFLAGS et LIBS pour obtenir la valeur de l'attribut linker.<br />
					Pour mieux comprendre, regardez ce fichier <a href="./fichiers/Makefile.Release" class="lienArticle">Makefile.Release</a> et le fichier <a href="./fichiers/Qt.template" class="lienArticle">Qt.template</a> qui en r�sulte.
				</div><br/>			
			
		
		<br /><h1 class="TitreSection0" id="LVI">VI. Conclusion</h1>
			
			<div class="paragraph">
				Voil�, maintenant il ne vous reste plus qu'� faire un simple Fichier-&gt;Nouveau-&gt;Projet pour obtenir un projet utilisant <b>Qt</b>. T�l�chargez l'<a href="ftp://www.ftp-developpez.com/nicolasj/qt4.zip" class="lienArticle">archive zipp�e</a> qu'il vous suffit d'extraire dans le r�pertoire template de <b>Dev-cpp</b>.
			</div><br/>
		
		<br /><h1 class="TitreSection0" id="LVII">VII. Remerciements</h1>
			
			<div class="paragraph">
				Merci � Bestiol pour la relecture attentive de cet article.
			</div><br/>
		
	<br/><hr/><p style="text-align:center;" class="cachee"><a href="http://validator.w3.org/check?uri=referer"><img src="http://www.w3.org/Icons/valid-xhtml11" alt="Valid XHTML 1.1!" height="31" width="88"/></a><a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!"/></a></p><div id="visites-logo" style="text-align:center;">
<!-- phpmyvisites -->
<a href="http://www.phpmyvisites.net/" title="phpMyVisites | Open source web analytics"
onclick="window.open(this.href);return(false);">
<script type="text/javascript">
<!--
var a_vars = Array();
var pagename='';
	  
var phpmyvisitesSite = 5;
var phpmyvisitesURL = "http://visites02.developpez.com/phpmyvisites.php";
//-->
</script>
<script type="text/javascript" src="http://visites02.developpez.com/phpmyvisites.js"></script>
<noscript>
<p>phpMyVisites | Open source web analytics
<img src="http://visites02.developpez.com/phpmyvisites.php" alt="phpMyVisites" style="border:0" />
</p>
</noscript>
</a>
<!-- /phpmyvisites -->
					</div>
			</td>
		</tr>
	</table>
</div>
<?
		include("$DOCUMENT_ROOT/template/pied.php");?>