//=============================================================--
// Nom de l'�tudiant   : David FISCHER TE3
// Nom du projet       : Cam�ra CMOS 2006
// Nom du Cpp          : mainwindow
// Nom de la FPGA      : Cyclone - EP1C12F256C7
// Nom de la puce USB2 : Cypress - FX2
// Nom du compilateur  : Qt
//=============================================================--

#include <QtGui>

#include "fenetre.h"
#include "mainwindow.h"

MainWindow::MainWindow()
{
     fenetre = new Fenetre;
     setCentralWidget(fenetre);
    //fenetre->showMaximized();
	 
     exitAct = new QAction(tr("E&xit"), this);
     exitAct->setShortcut(tr("Ctrl+Q"));
     connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));

     fileMenu = menuBar()->addMenu(tr("&File"));
     fileMenu->addAction(exitAct);
}
