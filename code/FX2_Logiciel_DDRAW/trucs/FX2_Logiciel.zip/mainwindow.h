//=============================================================--
// Nom de l'�tudiant   : David FISCHER TE3
// Nom du projet       : Cam�ra CMOS 2006
// Nom du H            : mainwindow
// Nom de la FPGA      : Cyclone - EP1C12F256C7
// Nom de la puce USB2 : Cypress - FX2
// Nom du compilateur  : Qt
//=============================================================--

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QAction;
class QMenu;
class Fenetre;

class MainWindow : public QMainWindow
{
     Q_OBJECT

public:
     MainWindow();

private:
     Fenetre *fenetre;
     QMenu   *fileMenu;
     QAction *exitAct;
 };

#endif
