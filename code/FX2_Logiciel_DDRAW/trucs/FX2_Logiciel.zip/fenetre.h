//=============================================================--
// Nom de l'�tudiant   : David FISCHER TE3
// Nom du projet       : Cam�ra CMOS 2006
// Nom du H            : fenetre
// Nom de la FPGA      : Cyclone - EP1C12F256C7
// Nom de la puce USB2 : Cypress - FX2
// Nom du compilateur  : Qt
//=============================================================--

#ifndef FENETRE_H
#define FENETRE_H
 
#include <QWidget>
#include <iostream>
#include <windows.h>
#include <winbase.h>
#include <string.h>
#include "CypressEzUSBDevice.h"
 
#define TAILLEX    16
#define TAILLEY    12
#define FACTEUR    16

using namespace std;

struct RVB
{
    unsigned char R;
    unsigned char V;
    unsigned char B;
};

struct RVBA
{
    unsigned char B;
    unsigned char V;
    unsigned char R;
    unsigned char A;
};
 
class QPushButton;
class QGroupBox;
class QLabel;
class QTextEdit;
class QPixmap;
class QImage;
class QTimer;
 
class Fenetre : public QWidget
{
     Q_OBJECT

public:
     Fenetre(QWidget *parent = 0);

private:
	 void createLabels();
	 void createEditor();
	 void createHorizontalGroupBox();

	 void ToHex (unsigned char pOctet, char* pHexa);
	 
	 void LectureBulk ();
	 
	 // Notre Buffer du Bulk FX2
	 unsigned char BufferBulk[2][512];
	 
	 // Notre Buffer Ecran en RVB
	 RVB  BufferRVB[TAILLEY][TAILLEX];
	 RVBA MatriceRVBA[TAILLEY*FACTEUR][TAILLEX*FACTEUR];
	 
     int PoBulk[2];
     int NoBulk[2];
     int NbBulk[2];
     
     int NoImage;
     
     int PupilleX, PupilleY;
	 
	 CypressEzUSBDevice NotreFX2;

	 enum { NumButtons = 3};
	 
	 QLabel      *labels;
     QTextEdit   *editor;
	 QGroupBox   *HorizontalGroupBox;
	 QPushButton *Buttons[NumButtons];
	 
	 QTimer      *Tempo;
	 QCursor     *Curseur;
     QImage       Image;
     QPixmap      Pixmap;    
	 
private slots:
	void Rafraichir ();        
};
#endif
