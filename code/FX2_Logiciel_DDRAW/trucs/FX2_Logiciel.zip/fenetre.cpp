//=============================================================--
// Nom de l'�tudiant   : David FISCHER TE3
// Nom du projet       : Cam�ra CMOS 2006
// Nom du Cpp          : fenetre
// Nom de la FPGA      : Cyclone - EP1C12F256C7
// Nom de la puce USB2 : Cypress - FX2
// Nom du compilateur  : Qt
//=============================================================--

#include <QtGui>

#include "fenetre.h"

Fenetre::Fenetre(QWidget *parent) : QWidget(parent)  
{   
    createLabels();
	createEditor();
	createHorizontalGroupBox();
	 
	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(labels); 
	//mainLayout->addStretch(1);
	mainLayout->addWidget(editor);
	mainLayout->addWidget(HorizontalGroupBox);
	setLayout(mainLayout);
    	 
    // Efface les Buffers
    
    for (int NoY = 0; NoY < TAILLEY; NoY++)
    for (int NoX = 0; NoX < TAILLEX; NoX++)
        BufferRVB[NoY][NoX].R =
        BufferRVB[NoY][NoX].V =
        BufferRVB[NoY][NoX].B = 0;
        
    /*for (int Y = 0; Y < TAILLEY; Y++)
    for (int X = 0; X < TAILLEX; X++)
    {
	    for (int dY = Y*FACTEUR; dY < Y*FACTEUR+FACTEUR; dY++)
		for (int dX = X*FACTEUR; dX < X*FACTEUR+FACTEUR; dX++)
		{
			MatriceRVBA[dY][dX].R = BufferRVB[Y][X].R;
			MatriceRVBA[dY][dX].V = BufferRVB[Y][X].V;
			MatriceRVBA[dY][dX].B = BufferRVB[Y][X].B;
			MatriceRVBA[dY][dX].A = 255;
		}
    }*/
 
    PoBulk[0] = 0;
    NoBulk[0] = 0;
    NbBulk[0] = 0;
    
    PoBulk[1] = 0;
    NoBulk[1] = 0;
    NbBulk[1] = 0;
    
    NoImage  = 0;
    PupilleX = 0;
    PupilleY = 0;
 
    // Initialisation de la Capture	
    
	Tempo = new QTimer (this);
	
	connect (Tempo, SIGNAL(timeout()), this, SLOT(Rafraichir()));
	
	Tempo->start (100);
}

void Fenetre::createLabels()
{   
    labels  = new QLabel(tr("vertical label"));
    QHBoxLayout *layout = new QHBoxLayout;
    labels->setLayout(layout);
	  
    setFixedSize (TAILLEX*FACTEUR, TAILLEY*FACTEUR);	 
}

void Fenetre::createEditor()
{
	editor  = new QTextEdit();
    QHBoxLayout *layout = new QHBoxLayout;
    editor->setLayout(layout);
}

void Fenetre::createHorizontalGroupBox()
{
	 HorizontalGroupBox  = new QGroupBox(tr("Horizontal layout"));
     QHBoxLayout *layout = new QHBoxLayout;

     for (int i = 0; i < NumButtons; ++i) 
	 {
         Buttons[i] = new QPushButton(tr("Button %1").arg(i + 1));
         layout->addWidget(Buttons[i]);
     } 
     HorizontalGroupBox->setLayout(layout);
}
 
// ============================================================--

void Fenetre::ToHex (unsigned char pOctet, char* pHexa)
{
	_itoa (pOctet,pHexa,16);
	
	if (pOctet < 16)
	{
		pHexa[1] = pHexa[0];
		pHexa[0] = '0';
    }
	
	for (int No = 0; No < 2; No++)
	{
		switch (pHexa[No])
		{
		case 'a': pHexa[No] = 'A'; break;
		case 'b': pHexa[No] = 'B'; break;
		case 'c': pHexa[No] = 'C'; break;
		case 'd': pHexa[No] = 'D'; break;
		case 'e': pHexa[No] = 'E'; break;
		case 'f': pHexa[No] = 'F'; break;
		}
	}
}

// ============================================================--

static char Texte[512*10];

// Lecture du FX2 s'il le faut...
void Fenetre::LectureBulk ()
{
    NoBulk[0]++;
    PoBulk[0] = 0;
    NbBulk[0] = NotreFX2.bulkRead (0, (char*)BufferBulk[0], 512);
    
    /*NoBulk[1]++;
    PoBulk[1] = 0;
    NbBulk[1] = NotreFX2.bulkRead (2, (char*)BufferBulk[1], 512);*/
         
     // Rafraichissement du Texte ----------------------

	 int NoCar = 0;

	 for (int No = 0; No < NbBulk[0]; No+=2)
	 {
         char HexaFort[3]   = {0,0,0};
         char HexaFaible[3] = {0,0,0};
            
	     ToHex (BufferBulk[0][No+1], HexaFort);
	     ToHex (BufferBulk[0][No+0], HexaFaible);
		
	     Texte[NoCar++] = HexaFort[0];
	     Texte[NoCar++] = HexaFort[1];
	     Texte[NoCar++] = ' ';
	     Texte[NoCar++] = HexaFaible[0];
	     Texte[NoCar++] = HexaFaible[1];
	     Texte[NoCar++] = ' ';
	     Texte[NoCar++] = '-';
	     Texte[NoCar++] = ' ';
	
	     if (No % 32 == 30)
	     {
		    Texte[NoCar++] = 0x0D;
		    Texte[NoCar++] = 0x0A;
	     }
    }
       
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
       
    Texte[NoCar++] = 'i';
    Texte[NoCar++] = 'm';
    Texte[NoCar++] = 'a';
    Texte[NoCar++] = 'g';
    Texte[NoCar++] = 'e';
    Texte[NoCar++] = ' ';
    
    _itoa (NoImage, (char*)&Texte[NoCar], 10);
       
    NoCar += strlen ((char*)&Texte[NoCar]);
       
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
  
    Texte[NoCar++] = 'n';
    Texte[NoCar++] = 'o';  
    Texte[NoCar++] = 'b';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'l';
    Texte[NoCar++] = 'k';
    Texte[NoCar++] = '0';
    Texte[NoCar++] = ' ';
       
    _itoa (NoBulk[0], (char*)&Texte[NoCar], 10);
       
    NoCar += strlen ((char*)&Texte[NoCar]);
    
    Texte[NoCar++] = ' '; 
    Texte[NoCar++] = 'n';
    Texte[NoCar++] = 'b';  
    Texte[NoCar++] = 'b';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'l';
    Texte[NoCar++] = 'k';
    Texte[NoCar++] = '0';
    Texte[NoCar++] = ' ';
       
    _itoa (NbBulk[0], (char*)&Texte[NoCar], 10);
    
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
    
    Texte[NoCar++] = 'n';
    Texte[NoCar++] = 'o'; 
    Texte[NoCar++] = 'b';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'l';
    Texte[NoCar++] = 'k';
    Texte[NoCar++] = '1';
    Texte[NoCar++] = ' ';
       
    _itoa (NoBulk[1], (char*)&Texte[NoCar], 10);
       
    NoCar += strlen ((char*)&Texte[NoCar]);
  
    Texte[NoCar++] = ' '; 
    Texte[NoCar++] = 'n';
    Texte[NoCar++] = 'b';  
    Texte[NoCar++] = 'b';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'l';
    Texte[NoCar++] = 'k';
    Texte[NoCar++] = '0';
    Texte[NoCar++] = ' ';
       
    _itoa (NbBulk[1], (char*)&Texte[NoCar], 10);
       
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
       
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
    
    Texte[NoCar++] = 'p';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'p';
    Texte[NoCar++] = 'x';
    Texte[NoCar++] = ' ';
       
    _itoa (PupilleX, (char*)&Texte[NoCar], 10);
       
    NoCar += strlen ((char*)&Texte[NoCar]);
       
    Texte[NoCar++] = 0x0D;
    Texte[NoCar++] = 0x0A;
    
    Texte[NoCar++] = 'p';
    Texte[NoCar++] = 'u';
    Texte[NoCar++] = 'p';
    Texte[NoCar++] = 'y';
    Texte[NoCar++] = ' ';
       
    _itoa (PupilleY, (char*)&Texte[NoCar], 10);
      
    NoCar += strlen ((char*)&Texte[NoCar]);
	
	editor->setText(Texte);
}

   /* Rectangle (0,0,  0,  0, 6,4);
    Rectangle (0,1,  6,  0, 6,4);
    Rectangle (0,2, 12,  0, 6,4);
    
    Rectangle (1,0,  6,  4, 3,2);
    Rectangle (1,1,  9,  4, 3,2);
 
    Rectangle (2,0,  0,  4, 6,4);
    Rectangle (2,1,  6,  6, 3,2);
    Rectangle (2,2,  9,  6, 3,2);
    Rectangle (2,3, 12,  4, 6,4);
    
    Rectangle (3,0,  0, 8, 6,4);
    Rectangle (3,1,  6, 8, 6,4);
    Rectangle (3,2, 12, 8, 6,4);*/
    
/*void Fenetre::Rectangle (int pdX, int pdY, int pmX, int pmY, int ptX, int ptY)
{
     for (int Y = pmY*FACTEUR; Y < (pmY+ptY)*FACTEUR; Y++)
     for (int X = pmX*FACTEUR; Y < (pmX+ptX)*FACTEUR; X++)
     {
		MatriceRVBA[Y][X].R = BufferRVB[pdY][pdX].R;
		MatriceRVBA[Y][X].V = BufferRVB[pdY][pdX].V;
		MatriceRVBA[Y][X].B = BufferRVB[pdY][pdX].B;
		MatriceRVBA[Y][X].A = 255;
     }
}*/

void Fenetre::Rafraichir ()
{
     // Efface les T�moins Position
     /*BufferRVB[TAILLEY-2][TAILLEX-4].R /= 2;
     BufferRVB[TAILLEY-2][TAILLEX-4].V /= 2;
     BufferRVB[TAILLEY-2][TAILLEX-4].B /= 2;
     BufferRVB[TAILLEY-2][TAILLEX-2].R /= 2;
     BufferRVB[TAILLEY-2][TAILLEX-2].V /= 2;
     BufferRVB[TAILLEY-2][TAILLEX-2].B /= 2;

    // Rafraichissement de l'Image -------------------

    bool DejaImage = false;
     
    int NoLigne = 0;
    int NoPixel = 0;

    while (true)
    {
        unsigned char PFaible = BufferBulk[0][PoBulk[0]+0];
        unsigned char PFort   = BufferBulk[0][PoBulk[0]+1];

        // Compteur Image
        if ((PFort & 0x80) == 0x80)
        {
            if (DejaImage) break;
             
            DejaImage = true;
            
            NoImage = (PFort & 0x7F)*256 + PFaible;
			NoLigne = 0;
        }

        // Compteur Ligne
        else if ((PFort & 0xC0) == 0x40)
        {
            NoLigne = (PFort & 0x3F)*256 + PFaible;
            NoPixel = 0;
        }

        // Paquet CRC
        else if ((PFort & 0xE0) == 0x20)
        {
        }

        // Paquet Pixel / Donn�es
        else if ((PFort & 0xF0) == 0x10)
        {
            // Le pixel doit �tre dans les marges!!
            if (NoPixel < 0) NoPixel = 0;
			if (NoPixel > TAILLEX-1) NoPixel = TAILLEX-1;
			
			if (NoLigne < 0) NoLigne = 0;
			if (NoLigne > TAILLEY-1) NoLigne = TAILLEY-1;

            // Affichage dans la Fen�tre
			switch (PFort)
			{
            // 0001 x type 00 couleur
            // 0001 x type 01 couleur
            // 0001 x type 10 couleur
			case 0x10: // Rouge
				BufferRVB[NoLigne][NoPixel].R = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].V = 0;
				BufferRVB[NoLigne][NoPixel].B = 0; break;
				
			case 0x11: // Vert
				BufferRVB[NoLigne][NoPixel].R = 0;
				BufferRVB[NoLigne][NoPixel].V = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].B = 0; break;
				
			case 0x12: // Bleu
				BufferRVB[NoLigne][NoPixel].R = 0;
				BufferRVB[NoLigne][NoPixel].V = 0;
				BufferRVB[NoLigne][NoPixel].B = PFaible; break; //255; break;
				
			case 0x14: // Teinte [Violet]
				BufferRVB[NoLigne][NoPixel].R = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].V = 0;
				BufferRVB[NoLigne][NoPixel].B = PFaible; break; //255; break;
				
			case 0x15: // Saturation [Jaune]
				BufferRVB[NoLigne][NoPixel].R = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].V = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].B = 0; break;
				
			case 0x16: // Luminance [Turquoise]
				BufferRVB[NoLigne][NoPixel].R = 0;
				BufferRVB[NoLigne][NoPixel].V = PFaible;//255;
				BufferRVB[NoLigne][NoPixel].B = PFaible; break; //255; break;
			
			case 0x18: // Position X
				BufferRVB[TAILLEY-2][TAILLEX-4].R = 255;
				BufferRVB[TAILLEY-2][TAILLEX-4].V = 255;
				BufferRVB[TAILLEY-2][TAILLEX-4].B = 255; break;
				
			case 0x19: // Position Y
				BufferRVB[TAILLEY-2][TAILLEX-2].R = 255;
				BufferRVB[TAILLEY-2][TAILLEX-2].V = 255;
				BufferRVB[TAILLEY-2][TAILLEX-2].B = 255; break;
			}
			
			// Traitement des Variables
			switch (PFort)
			{
			case 0x10: // Rouge	
			case 0x11: // Vert
			case 0x12: // Bleu
			case 0x14: // Teinte [Violet]
			case 0x15: // Saturation [Jaune]
			case 0x16: // Luminance [Turquoise]
			     NoPixel++; break;
			     
            case 0x18: PupilleX = PFaible; break;
            case 0x19: PupilleY = PFaible; break;
            }
        }
        
        // Lecture de la Trame Suivante
        PoBulk[0] += 2;
        
        if (PoBulk[0] >= NbBulk[0]) LectureBulk ();
    }*/
	
	/*const int cResX = 6*2*3/2;
	const int cResY = 4*2*3/2;
	const int cPerMoyX = 6;
	const int cPerMoyY = 4;
	const int cDetMoyX = 3;
	const int cDetMoyY = 2;
	const int cDetDebX = 6;
	const int cDetDebY = 4;
	const int cDetFinX = 11;
	const int cDetFinY = 7;*/
	
    /*Rectangle (0,0,  0,  0, 6,4);
    Rectangle (0,1,  6,  0, 6,4);
    Rectangle (0,2, 12,  0, 6,4);
    
    Rectangle (1,0,  6,  4, 3,2);
    Rectangle (1,1,  9,  4, 3,2);
 
    Rectangle (2,0,  0,  4, 6,4);
    Rectangle (2,1,  6,  6, 3,2);
    Rectangle (2,2,  9,  6, 3,2);
    Rectangle (2,3, 12,  4, 6,4);
    
    Rectangle (3,0,  0, 8, 6,4);
    Rectangle (3,1,  6, 8, 6,4);
    Rectangle (3,2, 12, 8, 6,4);
    
    Rectangle (TAILLEX-4,TAILLEY-2, TAILLEX-4, TAILLEY-2, FACTEUR, FACTEUR);
    Rectangle (TAILLEX-2,TAILLEY-2, TAILLEX-2, TAILLEY-2, FACTEUR, FACTEUR);*/
	
    for (int Y = 0; Y < TAILLEY; Y++)
    for (int X = 0; X < TAILLEX; X++)
    {
	    for (int dY = Y*FACTEUR; dY < Y*FACTEUR+FACTEUR; dY++)
		for (int dX = X*FACTEUR; dX < X*FACTEUR+FACTEUR; dX++)
		{
			MatriceRVBA[dY][dX].R = BufferRVB[Y][X].R;
			MatriceRVBA[dY][dX].V = BufferRVB[Y][X].V;
			MatriceRVBA[dY][dX].B = BufferRVB[Y][X].B;
			MatriceRVBA[dY][dX].A = 255;
		}
    }

    QImage Image ((unsigned char*)&MatriceRVBA, TAILLEX*FACTEUR,
                                                TAILLEY*FACTEUR,
                                                QImage::Format_ARGB32);
    QPixmap pix = QPixmap ::fromImage (Image);
    
    labels->setPixmap (pix);
}
